from .pygtkcompat import enable


__all__ = ["enable"]
