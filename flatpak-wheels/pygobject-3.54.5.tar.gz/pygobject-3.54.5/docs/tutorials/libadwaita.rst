Adwaita
=======

`Adwaita <https://gnome.pages.gitlab.gnome.org/libadwaita/>`_ (``libadwaita``)
offers application developers many widgets and objects to build GNOME
applications scaling from desktop workstations to mobile phones.

Adwaita is the library you must use if you want to build applications targeting
the GNOME desktop and follow its `Human Interface Guidelines <https://developer.gnome.org/hig/>`_.

.. toctree::
   :maxdepth: 3
   :caption: Contents

   libadwaita/application
